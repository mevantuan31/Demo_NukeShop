
CKEDITOR.plugins.setLang( 'eqneditor', 'en',
{
	title		: 'CodeCogs Equation Editor',
	menu    : 'Maths',
	toolbar	: 'Insert Equation',
	edit		: 'Edit Equation'
});
