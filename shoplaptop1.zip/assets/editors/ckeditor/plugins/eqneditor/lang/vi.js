CKEDITOR.plugins.setLang( 'eqneditor', 'vi',
{
	title	: 'Soạn công thức',
	menu    : 'Toán học',
	toolbar	: 'Thêm công thức',
	edit	: 'Sửa công thức'
});