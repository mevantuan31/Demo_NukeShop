<?php

/**
 * @Project NUKEVIET 4.x
 * @Author VINADES.,JSC (contact@vinades.vn)
 * @Copyright (C) 2014 VINADES.,JSC. All rights reserved
 * @License GNU/GPL version 2 or any later version
 * @Createdate 07/30/2013 10:27
 */

if (! defined('NV_ADMIN')) {
    die('Stop!!!');
}

$submenu['manage'] = $lang_module['manage'];
$submenu['newest'] = $lang_module['newest'];
$submenu['popular'] = $lang_module['popular'];
$submenu['featured'] = $lang_module['featured'];
$submenu['downloaded'] = $lang_module['downloaded'];
$submenu['favorites'] = $lang_module['favorites'];
