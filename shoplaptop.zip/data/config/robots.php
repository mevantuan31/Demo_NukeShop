<?php

/**
 * @Project NUKEVIET 4.x
 * @Author VINADES.,JSC <contact@vinades.vn>
 * @Copyright (C) 2020 VINADES.,JSC. All rights reserved
 * @License GNU/GPL version 2 or any later version
 * @Createdate Wed, 18 Nov 2020 02:52:06 GMT
 */

if ( ! defined( 'NV_MAINFILE' ) ) die( 'Stop!!!' );

$cache = 'a:19:{s:14:"/CHANGELOG.txt";s:1:"1";s:16:"/CONTRIBUTING.md";s:1:"1";s:14:"/COPYRIGHT.txt";s:1:"1";s:12:"/LICENSE.txt";s:1:"1";s:10:"/README.md";s:1:"1";s:7:"/admin/";s:1:"0";s:8:"/assets/";s:1:"1";s:11:"/config.php";s:1:"1";s:6:"/data/";s:1:"0";s:12:"/favicon.ico";s:1:"1";s:10:"/includes/";s:1:"0";s:10:"/index.php";s:1:"1";s:9:"/install/";s:1:"0";s:9:"/modules/";s:1:"0";s:11:"/robots.php";s:1:"0";s:11:"/robots.txt";s:1:"1";s:8:"/themes/";s:1:"1";s:9:"/uploads/";s:1:"1";s:11:"/web.config";s:1:"0";}';

$cache_other = 'a:2:{s:18:"/shoplaptop/users/";i:0;s:23:"/shoplaptop/statistics/";i:0;}';