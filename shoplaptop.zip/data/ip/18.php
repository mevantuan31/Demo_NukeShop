<?php

/**
 * @Project NUKEVIET 4.x
 * @This product includes GeoLite2 data created by MaxMind, available from http://www.maxmind.com
 * @Createdate Wed, 18 Apr 2018 03:19:55 GMT
 */

$ranges=array(301989888=>array(310509567,'US'),310509568=>array(310575103,'GB'),310575104=>array(310902783,'US'),310902784=>array(310968319,'SG'),310968320=>array(313720831,'US'),313720832=>array(313786367,'JP'),313786368=>array(313917439,'US'),313917440=>array(313982975,'JP'),313982976=>array(314048511,'US'),314048512=>array(314179583,'DE'),314179584=>array(314703871,'US'),314703872=>array(314966015,'DE'),314966016=>array(315097087,'US'),315097088=>array(315162623,'IE'),315162624=>array(316932095,'US'),316932096=>array(316997631,'BR'),316997632=>array(317128703,'US'),317128704=>array(317194239,'BR'),317194240=>array(318767103,'US'));
