<?php

/**
 * @Project NUKEVIET 4.x
 * @This product includes GeoLite2 data created by MaxMind, available from http://www.maxmind.com
 * @Createdate Wed, 18 Apr 2018 03:21:07 GMT
 */

$ranges=array(2231369728=>array(2239889407,'JP'),2239889408=>array(2239890431,'US'),2239890432=>array(2248146943,'JP'));
